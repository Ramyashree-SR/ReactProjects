import React from 'react'
import "./home.css"

function Home() {
  return (
    <div className="home">I m Home
        
    </div>
  )
}

export default Home